perl-api-bitstamp
=======================

Perl module for BitStamp API

Currently: only supports the public API requests. Private requests coming soon.

Update: now supports private requests too. But some are not tested... the ones that move funds.

These perl modules have not been extensively tested. Please use with caution.

There is no documentation (pods) yet. But the test.pl file should get you started.

A proper Perl module will be coming for CPAN that will allow you to 'make; make test; make install'.

